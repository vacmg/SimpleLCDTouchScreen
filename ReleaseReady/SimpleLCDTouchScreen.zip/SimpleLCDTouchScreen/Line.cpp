//
// Created by Víctor on 19/09/2021.
//

#include "Line.h"

Line::Line(int x, int y, int x1, int y1, Color mainColor): ScreenObjectWithXtraCoords(x, y, x1, y1, mainColor), ScreenObject(x, y, mainColor)
{

}
